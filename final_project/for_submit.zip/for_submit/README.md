My main work was done at `project.ipynb(project.html)`. I translated it to `poi_id.py` afterwards. For further answers to questions, please see `question.md`. I am grateful to the reviewer.
